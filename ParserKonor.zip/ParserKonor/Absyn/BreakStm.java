package Absyn;

public class BreakStm extends Stm {
    public BreakStm(int pos) {
        super(pos);
    }
}