package Absyn;

public class ConstantExpression {
    // You can extend this later to store actual expression value(s)
    // For now, just a placeholder

    public String value;  // optional: store as a string for simplicity

    public ConstantExpression(String v) {
        this.value = v;
    }
}
