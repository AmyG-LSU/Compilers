package Absyn;

public class ContinueStm extends Stm {
    public ContinueStm(int pos) {
        super(pos);
    }
}