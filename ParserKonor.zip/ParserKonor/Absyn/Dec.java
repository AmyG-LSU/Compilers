package Absyn;
import Symbol.Symbol;
abstract public class Dec
{
    public int pos = -1;
    public Dec() {}
    public Dec(int pos) { this.pos = pos; } 
}
