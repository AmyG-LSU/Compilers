package Absyn;

// Represents an empty array type: []
public class EmptyArrayType extends Dec {


    public EmptyArrayType() {
    }
}