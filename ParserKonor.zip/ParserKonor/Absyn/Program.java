// package Absyn;

// public class Program {
//     public Stm stm;  // top-level statement
//     public Exp exp;  // optional, if stm was an Expstm

//     public Program(Stm s) {
//         this.stm = s;
//         if (s instanceof Expstm)
//             this.exp = ((Expstm) s).expression;
//     }
// }
