package Absyn;

public abstract class Stm {
    public int pos;
    public Stm(int pos) {this.pos=pos;}
}