package Absyn;

public class StringExp extends Exp {
    public String value;
    public StringExp(String v) { this.value = v; }
}
