package Absyn;

public class VarExp extends Absyn {
    public Var var;
    public VarExp(Var v) { this.var = v; }
}
